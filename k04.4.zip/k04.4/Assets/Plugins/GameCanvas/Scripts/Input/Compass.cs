/*------------------------------------------------------------*/
// <summary>GameCanvas for Unity</summary>
// <author>Seibe TAKAHASHI</author>
// <remarks>
// (c) 2015-2019 Smart Device Programming.
// This software is released under the MIT License.
// http://opensource.org/licenses/mit-license.php
// </remarks>
/*------------------------------------------------------------*/

namespace GameCanvas.Input
{
    using UnityEngine;

    public sealed class Compass
    {
        //----------------------------------------------------------
        #region フィールド変数
        //----------------------------------------------------------

        // TODO

        #endregion

        //----------------------------------------------------------
        #region パブリック関数
        //----------------------------------------------------------

        // TODO

        #endregion

        //----------------------------------------------------------
        #region プライベート関数
        //----------------------------------------------------------

        /// <summary>
        /// コンストラクタ
        /// </summary>
        internal Compass()
        {
            // TODO
        }

        #endregion
    }
}
